# cookie-clicker-v2.052

Original game at http://orteil.dashnet.org/cookieclicker/

<img src="img/perfectCookie.png" width="128">

Click on "Code". <br>
Under "Code" click "Download ZIP". <br>
Once you have the file, open "index.html". <br>



# have fun
